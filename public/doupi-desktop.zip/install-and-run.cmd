@echo off
chcp 65001 >nul
setlocal EnableExtensions
title Install and run - Doupi 2.8.2

set "SOURCE=%~dp0"
set "TARGET=%LOCALAPPDATA%\DoupiPet2"

if not exist "%SOURCE%DoupiPet2.ps1" (
    echo Missing DoupiPet2.ps1. Please extract the ZIP completely first.
    pause
    exit /b 1
)
if not exist "%SOURCE%assets\spritesheet.png" (
    echo Missing assets\spritesheet.png. Please extract the ZIP completely first.
    pause
    exit /b 1
)
if not exist "%SOURCE%assets\poop-strip.png" (
    echo Missing assets\poop-strip.png. Please extract the ZIP completely first.
    pause
    exit /b 1
)
if not exist "%SOURCE%assets\curled.png" (
    echo Missing assets\curled.png. Please extract the ZIP completely first.
    pause
    exit /b 1
)
if not exist "%SOURCE%stop-existing.ps1" (
    echo Missing stop-existing.ps1. Please extract the ZIP completely first.
    pause
    exit /b 1
)

if not exist "%TARGET%" mkdir "%TARGET%"
if not exist "%TARGET%\assets" mkdir "%TARGET%\assets"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%SOURCE%stop-existing.ps1" -InstallRoot "%TARGET%" -SourceRoot "%SOURCE%"

copy /Y "%SOURCE%DoupiPet2.ps1" "%TARGET%\DoupiPet2.ps1" >nul
copy /Y "%SOURCE%DoupiPet2.vbs" "%TARGET%\DoupiPet2.vbs" >nul
copy /Y "%SOURCE%create-shortcut.ps1" "%TARGET%\create-shortcut.ps1" >nul
copy /Y "%SOURCE%stop-existing.ps1" "%TARGET%\stop-existing.ps1" >nul
copy /Y "%SOURCE%app-manifest.json" "%TARGET%\app-manifest.json" >nul
copy /Y "%SOURCE%README-Doupi2.8.2.md" "%TARGET%\README-Doupi2.8.2.md" >nul
copy /Y "%SOURCE%assets\spritesheet.png" "%TARGET%\assets\spritesheet.png" >nul
copy /Y "%SOURCE%assets\spritesheet.webp" "%TARGET%\assets\spritesheet.webp" >nul
copy /Y "%SOURCE%assets\pet.json" "%TARGET%\assets\pet.json" >nul
copy /Y "%SOURCE%assets\poop-strip.png" "%TARGET%\assets\poop-strip.png" >nul
copy /Y "%SOURCE%assets\curled.png" "%TARGET%\assets\curled.png" >nul
copy /Y "%SOURCE%validate_atlas.py" "%TARGET%\validate_atlas.py" >nul
if not exist "%TARGET%\settings.json" copy /Y "%SOURCE%settings.json" "%TARGET%\settings.json" >nul

if not exist "%TARGET%\DoupiPet2.ps1" (
    echo Install failed: cannot write to the current user application folder.
    pause
    exit /b 1
)
if not exist "%TARGET%\assets\spritesheet.png" (
    echo Install failed: the animation atlas was not copied.
    pause
    exit /b 1
)
if not exist "%TARGET%\assets\poop-strip.png" (
    echo Install failed: the poop animation was not copied.
    pause
    exit /b 1
)
if not exist "%TARGET%\assets\curled.png" (
    echo Install failed: the curled idle asset was not copied.
    pause
    exit /b 1
)

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%TARGET%\create-shortcut.ps1" -LauncherPath "%TARGET%\DoupiPet2.vbs"
if errorlevel 1 (
    echo Installation finished, but shortcut creation failed.
    echo You can start the pet from: %TARGET%\DoupiPet2.vbs
    pause
    exit /b 1
)

echo Doupi 2.8.2 is installed. Starting now...
wscript.exe "%TARGET%\DoupiPet2.vbs"
endlocal
