@echo off
call "%~dp0debug-doupi-2.cmd"
