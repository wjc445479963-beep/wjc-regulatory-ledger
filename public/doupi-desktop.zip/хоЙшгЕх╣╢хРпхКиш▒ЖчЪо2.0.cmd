@echo off
call "%~dp0install-and-run.cmd"
