﻿param(
    [Parameter(Mandatory = $true)]
    [string]$LauncherPath,
    [string]$ShortcutName = '豆皮 2.8.2.lnk'
)

$ErrorActionPreference = 'Stop'
$desktop = [Environment]::GetFolderPath('Desktop')
$startMenu = Join-Path ([Environment]::GetFolderPath('Programs')) '豆皮 2.8.2'
New-Item -ItemType Directory -Force -Path $startMenu | Out-Null
$shell = New-Object -ComObject WScript.Shell

function New-PetShortcut([string]$path) {
    $shortcut = $shell.CreateShortcut($path)
    $shortcut.TargetPath = Join-Path $env:WINDIR 'System32\wscript.exe'
    $shortcut.Arguments = '"' + $LauncherPath + '"'
    $shortcut.WorkingDirectory = Split-Path -Parent $LauncherPath
    $shortcut.Description = '启动豆皮独立桌面宠物 App 2.8.2'
    $shortcut.Save()
}

foreach ($oldPath in @(
    (Join-Path $desktop '豆皮 2.0.lnk'),
    (Join-Path ([Environment]::GetFolderPath('Programs')) '豆皮 2.0\豆皮 2.0.lnk'),
    (Join-Path $desktop '豆皮 2.1.lnk'),
    (Join-Path ([Environment]::GetFolderPath('Programs')) '豆皮 2.1\豆皮 2.1.lnk'),
    (Join-Path $desktop '豆皮 2.8.lnk'),
    (Join-Path ([Environment]::GetFolderPath('Programs')) '豆皮 2.8\豆皮 2.8.lnk'),
    (Join-Path $desktop '豆皮 2.8.1.lnk'),
    (Join-Path ([Environment]::GetFolderPath('Programs')) '豆皮 2.8.1\豆皮 2.8.1.lnk')
)) {
    if (Test-Path -LiteralPath $oldPath) { Remove-Item -LiteralPath $oldPath -Force -ErrorAction SilentlyContinue }
}
New-PetShortcut (Join-Path $desktop $ShortcutName)
New-PetShortcut (Join-Path $startMenu $ShortcutName)
