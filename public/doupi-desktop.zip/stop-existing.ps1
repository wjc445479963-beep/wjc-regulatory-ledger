﻿param(
    [Parameter(Mandatory = $true)]
    [string]$InstallRoot,
    [string]$SourceRoot = ''
)

$ErrorActionPreference = 'SilentlyContinue'
$scriptPaths = New-Object System.Collections.Generic.List[string]
$scriptPaths.Add([IO.Path]::GetFullPath((Join-Path $InstallRoot 'DoupiPet2.ps1')))
if ($SourceRoot) {
    $scriptPaths.Add([IO.Path]::GetFullPath((Join-Path $SourceRoot 'DoupiPet2.ps1')))
}

$candidatePids = New-Object System.Collections.Generic.HashSet[int]
$pidFiles = @((Join-Path $InstallRoot 'DoupiPet2.pid'))
if ($SourceRoot) { $pidFiles += (Join-Path $SourceRoot 'DoupiPet2.pid') }
foreach ($pidFile in $pidFiles) {
    if (-not (Test-Path -LiteralPath $pidFile -PathType Leaf)) { continue }
    $text = (Get-Content -LiteralPath $pidFile -Raw).Trim()
    $candidatePid = 0
    if ([int]::TryParse($text, [ref]$candidatePid) -and $candidatePid -gt 0) {
        [void]$candidatePids.Add($candidatePid)
    }
}

try {
    foreach ($processInfo in Get-CimInstance Win32_Process -Filter "Name = 'powershell.exe'") {
        $commandLine = [string]$processInfo.CommandLine
        foreach ($scriptPath in $scriptPaths) {
            if ($commandLine.IndexOf($scriptPath, [StringComparison]::OrdinalIgnoreCase) -ge 0) {
                [void]$candidatePids.Add([int]$processInfo.ProcessId)
                break
            }
        }
    }
} catch { }

foreach ($candidatePid in $candidatePids) {
    try {
        $processInfo = Get-CimInstance Win32_Process -Filter "ProcessId = $candidatePid"
        if ($null -eq $processInfo -or [string]$processInfo.Name -ine 'powershell.exe') { continue }
        $commandLine = [string]$processInfo.CommandLine
        $isExactPet = $false
        foreach ($scriptPath in $scriptPaths) {
            if ($commandLine.IndexOf($scriptPath, [StringComparison]::OrdinalIgnoreCase) -ge 0) {
                $isExactPet = $true
                break
            }
        }
        if ($isExactPet) { Stop-Process -Id $candidatePid -Force -ErrorAction SilentlyContinue }
    } catch { }
}
Start-Sleep -Milliseconds 350
