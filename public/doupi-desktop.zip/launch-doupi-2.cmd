@echo off
setlocal
wscript.exe "%~dp0DoupiPet2.vbs"
endlocal
