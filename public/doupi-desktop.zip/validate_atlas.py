#!/usr/bin/env python3
"""Validate the fixed Doupi v2 asset contract without starting the app."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from PIL import Image


def check_image(path: Path, expected: tuple[int, int], errors: list[str]) -> None:
    if not path.is_file():
        errors.append(f"missing={path.as_posix()}")
        return
    with Image.open(path) as image:
        if image.size != expected:
            errors.append(f"size={path.as_posix()}:{image.width}x{image.height}")
        if "A" not in image.getbands():
            errors.append(f"missing-alpha={path.as_posix()}")


def check_transparent_padding(path: Path, errors: list[str]) -> None:
    if not path.is_file():
        return
    with Image.open(path).convert("RGBA") as image:
        alpha = image.getchannel("A")
        solid = alpha.point(lambda value: 255 if value > 8 else 0)
        bbox = solid.getbbox()
        if bbox is not None and (
            bbox[0] == 0 or bbox[1] == 0 or bbox[2] == image.width or bbox[3] == image.height
        ):
            errors.append(f"insufficient-transparent-padding={path.as_posix()}:{bbox}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--require-v2", action="store_true")
    args = parser.parse_args()

    root = Path(__file__).resolve().parent
    errors: list[str] = []
    check_image(root / "assets" / "spritesheet.png", (1536, 2288), errors)
    check_image(root / "assets" / "poop-strip.png", (1536, 208), errors)
    check_image(root / "assets" / "curled.png", (192, 208), errors)
    check_transparent_padding(root / "assets" / "curled.png", errors)

    pet_json = root / "assets" / "pet.json"
    if args.require_v2:
        try:
            data = json.loads(pet_json.read_text(encoding="utf-8"))
            if data.get("spriteVersionNumber") != 2:
                errors.append("spriteVersionNumber!=2")
        except Exception as exc:  # pragma: no cover - diagnostic path
            errors.append(f"pet-json={exc}")

    result = {
        "ok": not errors,
        "atlas": "1536x2288",
        "curledIdle": "192x208",
        "groomingFrames": [],
        "requireV2": args.require_v2,
        "errors": errors,
    }
    print(json.dumps(result, ensure_ascii=False, separators=(",", ":")))
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
