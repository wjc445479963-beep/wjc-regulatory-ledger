﻿param(
    [string]$DebugLogPath = '',
    [switch]$SelfTest,
    [int]$SmokeTestSeconds = 0,
    [switch]$SmokeDemo
)

$ErrorActionPreference = 'Stop'

Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase

$script:appRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$script:assetRoot = Join-Path $script:appRoot 'assets'
$script:sheetPath = Join-Path $script:assetRoot 'spritesheet.png'
$script:poopStripPath = Join-Path $script:assetRoot 'poop-strip.png'
$script:curledPath = Join-Path $script:assetRoot 'curled.png'
$script:settingsPath = Join-Path $script:appRoot 'settings.json'
$script:pidPath = Join-Path $script:appRoot 'DoupiPet2.pid'
$script:cellWidth = 192
$script:cellHeight = 208

function Write-DebugLog([string]$message) {
    if ([string]::IsNullOrWhiteSpace($DebugLogPath)) { return }
    try {
        [IO.File]::AppendAllText($DebugLogPath, "$(Get-Date -Format o) $message`r`n")
    } catch { }
}

$script:animations = @{
    idle      = @('0:0')
    scratchLift = @('0:1','0:2')
    scratchStroke = @('0:3','0:2')
    scratchLower = @('0:1','0:0')
    right     = @('1:0','1:1','1:2','1:3','1:4','1:5','1:6','1:7')
    left      = @('2:0','2:1','2:2','2:3','2:4','2:5','2:6','2:7')
    toy       = @('4:0','4:1','4:2','4:3','4:4','4:3','4:2','4:1')
    lieDown   = @('5:0','5:1','5:2','5:3','5:4')
    lieUp     = @('5:4','5:5','5:6','5:7')
    lie       = @('5:0','5:1','5:2','5:3','5:4','5:5','5:6','5:7')
    poop      = @('p:0','p:1','p:2','p:3','p:4','p:5','p:6','p:7')
    curled    = @('c:0')
}

$script:animationDurations = @{
    idle      = @(1000)
    scratchLift = @(260,320)
    scratchStroke = @(250,250)
    scratchLower = @(260,360)
    right     = @(120,120,120,120,120,120,120,220)
    left      = @(120,120,120,120,120,120,120,220)
    toy       = @(150,140,140,180,230,180,140,140)
    lieDown   = @(260,280,300,380,520)
    lieUp     = @(520,420,320,520)
    lie       = @(260,280,300,380,520,420,320,520)
    poop      = @(260,280,300,380,520,420,320,520)
    curled    = @(1000)
}

$script:defaultSettings = [ordered]@{
    settingsVersion = 2
    displayScale = 0.52
    idlePoseRotationMinutes = 20
    scratchIntervalSeconds = 120
    toyIntervalSeconds = 60
    patrolIntervalSeconds = 90
    poopIntervalSeconds = 3600
    poopLifetimeSeconds = 25
}

function Load-Settings {
    $loaded = [ordered]@{}
    foreach ($key in $script:defaultSettings.Keys) {
        $loaded[$key] = $script:defaultSettings[$key]
    }
    $hasSettingsVersion = $false
    if (Test-Path -LiteralPath $script:settingsPath -PathType Leaf) {
        try {
            $json = Get-Content -LiteralPath $script:settingsPath -Raw | ConvertFrom-Json
            foreach ($key in $script:defaultSettings.Keys) {
                $property = $json.PSObject.Properties[$key]
                if ($null -ne $property) {
                    $loaded[$key] = $property.Value
                    if ($key -eq 'settingsVersion') { $hasSettingsVersion = $true }
                }
            }
            if (-not $hasSettingsVersion) {
                # v2.0-final3 以前的设置没有版本号；只迁移程序原来的默认值，保留用户已自定义的频率。
                if ([int]$loaded['toyIntervalSeconds'] -eq 90) { $loaded['toyIntervalSeconds'] = 60 }
                if ([int]$loaded['patrolIntervalSeconds'] -eq 60) { $loaded['patrolIntervalSeconds'] = 90 }
                if ([int]$loaded['scratchIntervalSeconds'] -eq 60) { $loaded['scratchIntervalSeconds'] = 120 }
                if ([int]$loaded['poopIntervalSeconds'] -eq 90) { $loaded['poopIntervalSeconds'] = 3600 }
                $loaded['settingsVersion'] = 2
                Write-DebugLog 'settings-migrated=2'
            }
        } catch {
            Write-DebugLog ('settings-load-error=' + $_.Exception.Message)
        }
    }
    return $loaded
}

function Save-Settings {
    try {
        $json = $script:settings | ConvertTo-Json -Depth 4
        [IO.File]::WriteAllText($script:settingsPath, $json, (New-Object Text.UTF8Encoding($false)))
    } catch {
        Write-DebugLog ('settings-save-error=' + $_.Exception.Message)
    }
}

if (-not (Test-Path -LiteralPath $script:sheetPath -PathType Leaf)) {
    if ($SelfTest) {
        Write-Output '{"ok":false,"error":"missing spritesheet.png"}'
        exit 1
    }
    [System.Windows.MessageBox]::Show('找不到 assets\spritesheet.png，豆皮 2.8.2 无法启动。','豆皮 2.8.2') | Out-Null
    exit 1
}

$script:sheet = New-Object System.Windows.Media.Imaging.BitmapImage
$script:sheet.BeginInit()
$script:sheet.UriSource = New-Object System.Uri($script:sheetPath, [System.UriKind]::Absolute)
$script:sheet.CacheOption = [System.Windows.Media.Imaging.BitmapCacheOption]::OnLoad
$script:sheet.CreateOptions = [System.Windows.Media.Imaging.BitmapCreateOptions]::PreservePixelFormat
$script:sheet.EndInit()
$script:sheet.Freeze()

$script:poopSheet = $null
if (Test-Path -LiteralPath $script:poopStripPath -PathType Leaf) {
    $script:poopSheet = New-Object System.Windows.Media.Imaging.BitmapImage
    $script:poopSheet.BeginInit()
    $script:poopSheet.UriSource = New-Object System.Uri($script:poopStripPath, [System.UriKind]::Absolute)
    $script:poopSheet.CacheOption = [System.Windows.Media.Imaging.BitmapCacheOption]::OnLoad
    $script:poopSheet.CreateOptions = [System.Windows.Media.Imaging.BitmapCreateOptions]::PreservePixelFormat
    $script:poopSheet.EndInit()
    $script:poopSheet.Freeze()
}

$script:curledSheet = $null
if (Test-Path -LiteralPath $script:curledPath -PathType Leaf) {
    $script:curledSheet = New-Object System.Windows.Media.Imaging.BitmapImage
    $script:curledSheet.BeginInit()
    $script:curledSheet.UriSource = New-Object System.Uri($script:curledPath, [System.UriKind]::Absolute)
    $script:curledSheet.CacheOption = [System.Windows.Media.Imaging.BitmapCacheOption]::OnLoad
    $script:curledSheet.CreateOptions = [System.Windows.Media.Imaging.BitmapCreateOptions]::PreservePixelFormat
    $script:curledSheet.EndInit()
    $script:curledSheet.Freeze()
}

if ($SelfTest) {
    $errors = New-Object System.Collections.Generic.List[string]
    if ($script:sheet.PixelWidth -ne 1536 -or $script:sheet.PixelHeight -ne 2288) {
        $errors.Add("atlas-size=$($script:sheet.PixelWidth)x$($script:sheet.PixelHeight)")
    }
    if ($null -eq $script:poopSheet) {
        $errors.Add('missing poop-strip.png')
    } elseif ($script:poopSheet.PixelWidth -ne 1536 -or $script:poopSheet.PixelHeight -ne 208) {
        $errors.Add("poop-strip-size=$($script:poopSheet.PixelWidth)x$($script:poopSheet.PixelHeight)")
    }
    if ($null -eq $script:curledSheet) {
        $errors.Add('missing curled.png')
    } elseif ($script:curledSheet.PixelWidth -ne 192 -or $script:curledSheet.PixelHeight -ne 208) {
        $errors.Add("curled-size=$($script:curledSheet.PixelWidth)x$($script:curledSheet.PixelHeight)")
    }
    foreach ($animationName in $script:animations.Keys) {
        $frames = @($script:animations[$animationName])
        $durations = @($script:animationDurations[$animationName])
        if ($frames.Count -ne $durations.Count) {
            $errors.Add("duration-count=$animationName")
        }
        foreach ($frameId in $frames) {
            $parts = $frameId -split ':'
            if ($parts[0] -eq 'p') {
                $row = 0
                $column = [int]$parts[1]
                if ($column -lt 0 -or $column -gt 7) { $errors.Add("poop-frame-range=$frameId") }
                continue
            }
            if ($parts[0] -eq 'c') {
                if ([int]$parts[1] -ne 0) { $errors.Add("curled-frame-range=$frameId") }
                continue
            }
            $row = [int]$parts[0]
            $column = [int]$parts[1]
            if ($row -lt 0 -or $row -gt 10 -or $column -lt 0 -or $column -gt 7) {
                $errors.Add("frame-range=$frameId")
            }
        }
    }
    $result = [ordered]@{
        ok = ($errors.Count -eq 0)
        atlas = "$($script:sheet.PixelWidth)x$($script:sheet.PixelHeight)"
        animationCount = $script:animations.Count
        defaults = $script:defaultSettings
        errors = @($errors)
    }
    Write-Output ($result | ConvertTo-Json -Depth 5 -Compress)
    if ($errors.Count -gt 0) { exit 1 }
    exit 0
}

$mutexCreated = $false
$script:instanceMutex = [Threading.Mutex]::new($true, 'Local\DoupiDesktopPet2', [ref]$mutexCreated)
if (-not $mutexCreated) { exit 0 }
try { [IO.File]::WriteAllText($script:pidPath, [string]$PID) } catch { }

$script:settings = Load-Settings
$script:frameCache = @{}
$script:hitCache = @{}
$script:currentHitSource = $null
$script:currentFrameId = ''
$script:currentAction = 'idle'
$script:actionAnimation = 'idle'
$script:actionStartedAt = [DateTime]::UtcNow
$script:actionDurationMs = 0.0
$script:actionPoopDropped = $false
$script:paused = $false
$script:dragging = $false
$script:smokeMode = ($SmokeTestSeconds -gt 0)
$script:smokeTimer = $null
$script:lastDirection = 'right'
$script:scratchCyclesRemaining = 0
$script:scratchLiftMs = 0.0
$script:scratchStrokeMs = 0.0
$script:scratchLowerMs = 0.0
$script:patrolStartLeft = 0.0
$script:patrolTargetLeft = 0.0
$script:patrolReturnLeft = 0.0
$script:patrolOutDirection = 1.0
$script:patrolNextDirection = if ((Get-Random -Minimum 0 -Maximum 2) -eq 0) { -1.0 } else { 1.0 }
$script:patrolRunCount = 0
$script:poopEffects = @()
$script:idlePose = 'sit'
$script:idlePoseMode = 'auto'
$script:idlePoseTransition = ''
$script:idlePoseTransitionStartedAt = [DateTime]::UtcNow
$script:nextIdlePoseAt = [DateTime]::UtcNow.AddMinutes([Math]::Max(1.0, [double]$script:settings['idlePoseRotationMinutes']))
$script:lastEngineErrorAt = [DateTime]::MinValue

function Get-FrameSource([string]$frameId) {
    if ($script:frameCache.ContainsKey($frameId)) { return $script:frameCache[$frameId] }
    $parts = $frameId -split ':'
    $source = $script:sheet
    if ($parts[0] -eq 'p') {
        $row = 0
        $source = $script:poopSheet
    } elseif ($parts[0] -eq 'c') {
        $row = 0
        $source = $script:curledSheet
    } else {
        $row = [int]$parts[0]
    }
    $column = [int]$parts[1]
    $rect = New-Object System.Windows.Int32Rect(
        ($column * $script:cellWidth),
        ($row * $script:cellHeight),
        $script:cellWidth,
        $script:cellHeight
    )
    $crop = New-Object System.Windows.Media.Imaging.CroppedBitmap($source, $rect)
    $crop.Freeze()
    $script:frameCache[$frameId] = $crop
    return $crop
}

function Get-HitSource([string]$frameId) {
    if ($script:hitCache.ContainsKey($frameId)) { return $script:hitCache[$frameId] }
    $converted = New-Object System.Windows.Media.Imaging.FormatConvertedBitmap
    $converted.BeginInit()
    $converted.Source = Get-FrameSource $frameId
    $converted.DestinationFormat = [System.Windows.Media.PixelFormats]::Bgra32
    $converted.EndInit()
    $converted.Freeze()
    $script:hitCache[$frameId] = $converted
    return $converted
}

function Set-Frame([string]$frameId) {
    if ($script:currentFrameId -eq $frameId) { return }
    $script:currentFrameId = $frameId
    $script:petImage.Source = Get-FrameSource $frameId
    $script:currentHitSource = Get-HitSource $frameId
}

function Test-PetPixel([System.Windows.Point]$point) {
    try {
        if ($null -eq $script:currentHitSource -or $script:petImage.ActualWidth -le 0 -or $script:petImage.ActualHeight -le 0) { return $false }
        if ($point.X -lt 0 -or $point.Y -lt 0 -or $point.X -ge $script:petImage.ActualWidth -or $point.Y -ge $script:petImage.ActualHeight) { return $false }
        $x = [Math]::Min($script:currentHitSource.PixelWidth - 1, [Math]::Max(0, [int][Math]::Floor($point.X / $script:petImage.ActualWidth * $script:currentHitSource.PixelWidth)))
        $y = [Math]::Min($script:currentHitSource.PixelHeight - 1, [Math]::Max(0, [int][Math]::Floor($point.Y / $script:petImage.ActualHeight * $script:currentHitSource.PixelHeight)))
        $pixel = New-Object byte[] 4
        $rect = New-Object System.Windows.Int32Rect($x, $y, 1, 1)
        $script:currentHitSource.CopyPixels($rect, $pixel, 4, 0)
        return ($pixel[3] -ge 48)
    } catch {
        Write-DebugLog ('hit-test-error=' + $_.Exception.Message)
        return $false
    }
}

function Get-AnimationCycleMs([string]$name) {
    $sum = 0.0
    foreach ($duration in $script:animationDurations[$name]) { $sum += [double]$duration }
    return $sum
}

function Show-AnimationFrame([string]$name, [double]$elapsedMs) {
    $frames = @($script:animations[$name])
    $durations = @($script:animationDurations[$name])
    if ($frames.Count -eq 1) { Set-Frame $frames[0]; return }
    $cycle = Get-AnimationCycleMs $name
    $within = $elapsedMs % $cycle
    $cursor = 0.0
    for ($i = 0; $i -lt $frames.Count; $i++) {
        $cursor += [double]$durations[$i]
        if ($within -lt $cursor) { Set-Frame $frames[$i]; return }
    }
    Set-Frame $frames[$frames.Count - 1]
}

function Reset-PetTransform {
    $script:petScale.ScaleX = 1.0
    $script:petScale.ScaleY = 1.0
    $script:petRotate.Angle = 0.0
    $script:petTranslate.X = 0.0
    $script:petTranslate.Y = 0.0
}

function Get-AutoScale {
    $workArea = [System.Windows.SystemParameters]::WorkArea
    return [Math]::Max(0.45, [Math]::Min(0.62, ([double]$workArea.Height / 1800.0)))
}

function Set-DisplayScale([double]$scale, [bool]$save = $true) {
    $scale = [Math]::Max(0.42, [Math]::Min(0.75, $scale))
    $oldRight = $window.Left + $window.Width
    $oldBottom = $window.Top + $window.Height
    $script:displayScale = $scale
    $width = [Math]::Round($script:cellWidth * $scale)
    $height = [Math]::Round($script:cellHeight * $scale)
    $window.Width = $width
    $window.Height = $height
    $script:petImage.Width = $width
    $script:petImage.Height = $height
    $script:canvas.Width = $width
    $script:canvas.Height = $height
    [System.Windows.Controls.Canvas]::SetLeft($script:petImage, 0.0)
    [System.Windows.Controls.Canvas]::SetTop($script:petImage, 0.0)
    $ballSize = [Math]::Max(10.0, [Math]::Round(22.0 * $scale))
    $script:toyBall.Width = $ballSize
    $script:toyBall.Height = $ballSize
    if ($oldRight -gt 0 -and $oldBottom -gt 0) {
        $window.Left = $oldRight - $width
        $window.Top = $oldBottom - $height
    }
    if ($save) {
        $script:settings['displayScale'] = $scale
        Save-Settings
    }
}

function Reset-NextDue([string]$kind) {
    $now = [DateTime]::UtcNow
    switch ($kind) {
        'scratch' {
            $seconds = [int]$script:settings['scratchIntervalSeconds']
            $script:nextScratchAt = if ($seconds -gt 0) { $now.AddSeconds($seconds) } else { [DateTime]::MaxValue }
        }
        'toy' {
            $seconds = [int]$script:settings['toyIntervalSeconds']
            $script:nextToyAt = if ($seconds -gt 0) { $now.AddSeconds($seconds) } else { [DateTime]::MaxValue }
        }
        'patrol' {
            $seconds = [int]$script:settings['patrolIntervalSeconds']
            $script:nextPatrolAt = if ($seconds -gt 0) { $now.AddSeconds($seconds) } else { [DateTime]::MaxValue }
        }
        'poop' {
            $seconds = [int]$script:settings['poopIntervalSeconds']
            $script:nextPoopAt = if ($seconds -gt 0) { $now.AddSeconds($seconds) } else { [DateTime]::MaxValue }
        }
    }
}

function Set-IntervalSetting([string]$kind, [int]$seconds) {
    $key = $kind + 'IntervalSeconds'
    $script:settings[$key] = [Math]::Max(0, $seconds)
    Save-Settings
    Reset-NextDue $kind
    Write-DebugLog "interval-$kind=$seconds"
}

function Get-IdleRotationMinutes {
    return [Math]::Max(1.0, [double]$script:settings['idlePoseRotationMinutes'])
}

function Set-IdleRotationMinutes([int]$minutes) {
    $script:settings['idlePoseRotationMinutes'] = [Math]::Max(1, $minutes)
    Save-Settings
    if ($script:idlePoseMode -eq 'auto') {
        $script:nextIdlePoseAt = [DateTime]::UtcNow.AddMinutes((Get-IdleRotationMinutes))
    }
    Write-DebugLog "idle-rotation-minutes=$minutes"
}

function Start-IdlePoseTransition([string]$target) {
    if ($target -notin @('lie','sit','curled')) { return }
    if ($target -eq $script:idlePose) { $script:nextIdlePoseAt = [DateTime]::UtcNow.AddMinutes((Get-IdleRotationMinutes)); return }
    if ($target -eq 'curled') {
        $script:idlePoseTransition = 'to-curled'
    } elseif ($script:idlePose -eq 'curled') {
        $script:idlePoseTransition = if ($target -eq 'lie') { 'from-curled-to-lie' } else { 'from-curled-to-sit' }
    } else {
        $script:idlePoseTransition = if ($target -eq 'lie') { 'to-lie' } else { 'to-sit' }
    }
    $script:idlePoseTransitionStartedAt = [DateTime]::UtcNow
    Write-DebugLog "idle-pose-transition=$($script:idlePoseTransition)"
}

function Resolve-IdlePoseTransition {
    switch ($script:idlePoseTransition) {
        'to-lie' { $script:idlePose = 'lie' }
        'to-sit' { $script:idlePose = 'sit' }
        'to-curled' { $script:idlePose = 'curled' }
        'from-curled-to-lie' { $script:idlePose = 'lie' }
        'from-curled-to-sit' { $script:idlePose = 'sit' }
    }
    $script:idlePoseTransition = ''
}

function Set-StableIdleFrame {
    switch ($script:idlePose) {
        'lie' { Set-Frame '5:4' }
        'curled' { Set-Frame 'c:0' }
        default { Set-Frame '0:0' }
    }
}

function Set-IdlePoseMode([string]$mode) {
    if ($mode -notin @('auto','sit','lie','curled')) { return }
    if ($script:currentAction -ne 'idle') { End-Action }
    Resolve-IdlePoseTransition
    $script:idlePoseMode = $mode
    if ($mode -eq 'auto') {
        $script:nextIdlePoseAt = [DateTime]::UtcNow.AddMinutes((Get-IdleRotationMinutes))
        Write-DebugLog 'idle-pose-mode=auto'
        return
    }
    $script:nextIdlePoseAt = [DateTime]::MaxValue
    if ($script:idlePose -ne $mode) { Start-IdlePoseTransition $mode }
    else { Set-StableIdleFrame }
    Write-DebugLog "idle-pose-mode=$mode"
}

function Update-IdlePose([DateTime]$now) {
    if ($script:idlePoseTransition -eq 'to-curled') {
        $elapsed = ($now - $script:idlePoseTransitionStartedAt).TotalMilliseconds
        Set-Frame 'c:0'
        if ($elapsed -ge 420) {
            $script:idlePose = 'curled'
            $script:idlePoseTransition = ''
            $script:nextIdlePoseAt = if ($script:idlePoseMode -eq 'auto') { $now.AddMinutes((Get-IdleRotationMinutes)) } else { [DateTime]::MaxValue }
            Write-DebugLog 'idle-pose=curled'
        }
        return
    }
    if ($script:idlePoseTransition -eq 'from-curled-to-lie' -or $script:idlePoseTransition -eq 'from-curled-to-sit') {
        $elapsed = ($now - $script:idlePoseTransitionStartedAt).TotalMilliseconds
        if ($elapsed -lt 360) { Set-Frame 'c:0'; return }
        $targetAnimation = if ($script:idlePoseTransition -eq 'from-curled-to-lie') { 'lieDown' } else { 'lieUp' }
        $transitionElapsed = $elapsed - 360
        Show-AnimationFrame $targetAnimation $transitionElapsed
        if ($transitionElapsed -ge (Get-AnimationCycleMs $targetAnimation)) {
            $script:idlePose = if ($targetAnimation -eq 'lieDown') { 'lie' } else { 'sit' }
            $script:idlePoseTransition = ''
            $script:nextIdlePoseAt = if ($script:idlePoseMode -eq 'auto') { $now.AddMinutes((Get-IdleRotationMinutes)) } else { [DateTime]::MaxValue }
            Set-StableIdleFrame
            Write-DebugLog "idle-pose=$($script:idlePose)"
        }
        return
    }
    if ($script:idlePoseTransition -eq 'to-lie') {
        $elapsed = ($now - $script:idlePoseTransitionStartedAt).TotalMilliseconds
        Show-AnimationFrame 'lieDown' $elapsed
        if ($elapsed -ge (Get-AnimationCycleMs 'lieDown')) {
            $script:idlePose = 'lie'
            $script:idlePoseTransition = ''
            $script:nextIdlePoseAt = if ($script:idlePoseMode -eq 'auto') { $now.AddMinutes((Get-IdleRotationMinutes)) } else { [DateTime]::MaxValue }
            Set-Frame '5:4'
            Write-DebugLog 'idle-pose=lie'
        }
        return
    }
    if ($script:idlePoseTransition -eq 'to-sit') {
        $elapsed = ($now - $script:idlePoseTransitionStartedAt).TotalMilliseconds
        Show-AnimationFrame 'lieUp' $elapsed
        if ($elapsed -ge (Get-AnimationCycleMs 'lieUp')) {
            $script:idlePose = 'sit'
            $script:idlePoseTransition = ''
            $script:nextIdlePoseAt = if ($script:idlePoseMode -eq 'auto') { $now.AddMinutes((Get-IdleRotationMinutes)) } else { [DateTime]::MaxValue }
            Set-Frame '0:0'
            Write-DebugLog 'idle-pose=sit'
        }
        return
    }
    if ($script:idlePoseMode -eq 'auto' -and $now -ge $script:nextIdlePoseAt) {
        $poseSequence = @('sit','lie','curled')
        $currentIndex = [Array]::IndexOf($poseSequence, $script:idlePose)
        if ($currentIndex -lt 0) { $currentIndex = 0 }
        $target = $poseSequence[($currentIndex + 1) % $poseSequence.Count]
        Start-IdlePoseTransition $target
        Update-IdlePose $now
        return
    }
    Set-StableIdleFrame
}

function Close-AllPoop {
    if ($null -eq $script:poopEffects) { $script:poopEffects = @(); return }
    foreach ($effect in @($script:poopEffects)) {
        if ($null -eq $effect) { continue }
        try { if ($null -ne $effect.Timer) { $effect.Timer.Stop() } } catch { }
        try { if ($null -ne $effect.Window) { $effect.Window.Close() } } catch { }
    }
    $script:poopEffects = @()
}

function New-PoopWindow {
    while ($script:poopEffects.Count -ge 3) {
        $oldest = $script:poopEffects[0]
        try { $oldest.Timer.Stop(); $oldest.Window.Close() } catch { }
        $script:poopEffects = @($script:poopEffects | Select-Object -Skip 1)
    }

    $effectWindow = New-Object System.Windows.Window
    $effectWindow.WindowStyle = [System.Windows.WindowStyle]::None
    $effectWindow.ResizeMode = [System.Windows.ResizeMode]::NoResize
    $effectWindow.AllowsTransparency = $true
    $effectWindow.Background = [System.Windows.Media.Brushes]::Transparent
    $effectWindow.ShowInTaskbar = $false
    $effectWindow.Topmost = $true
    $effectWindow.ShowActivated = $false
    $effectWindow.Owner = $window
    $effectWindow.Width = [Math]::Max(28, [Math]::Round(42 * $script:displayScale))
    $effectWindow.Height = $effectWindow.Width

    $poopText = New-Object System.Windows.Controls.TextBlock
    $poopText.Text = [char]::ConvertFromUtf32(0x1F4A9)
    $poopText.FontFamily = New-Object System.Windows.Media.FontFamily('Segoe UI Emoji')
    $poopText.FontSize = [Math]::Max(21, [Math]::Round(32 * $script:displayScale))
    $poopText.HorizontalAlignment = [System.Windows.HorizontalAlignment]::Center
    $poopText.VerticalAlignment = [System.Windows.VerticalAlignment]::Center
    $poopText.ToolTip = '点击清理'
    $effectWindow.Content = $poopText

    $workArea = [System.Windows.SystemParameters]::WorkArea
    $gap = [Math]::Max(14.0, [Math]::Round(18.0 * $script:displayScale))
    $rightSpace = $workArea.Right - ($window.Left + $window.Width)
    $leftSpace = $window.Left - $workArea.Left
    $avoidDistance = $effectWindow.Width + $gap
    if ($rightSpace -ge ($effectWindow.Width + $gap + 4.0)) {
        # 豆皮的尾巴在身体右侧：优先把便便放在尾巴外侧，并留出清晰间距。
        $effectWindow.Left = $window.Left + $window.Width + $gap
        $avoidDirection = -1.0
    } elseif ($leftSpace -ge ($effectWindow.Width + $gap + 4.0)) {
        $effectWindow.Left = $window.Left - $effectWindow.Width - $gap
        $avoidDirection = 1.0
    } else {
        # 屏幕边缘空间不足时仍保持在身体外侧，不把便便压到豆皮身下。
        $avoidDirection = if ($rightSpace -ge $leftSpace) { -1.0 } else { 1.0 }
        if ($avoidDirection -lt 0) {
            $effectWindow.Left = [Math]::Min($workArea.Right - $effectWindow.Width - 4.0, $window.Left + $window.Width + $gap)
        } else {
            $effectWindow.Left = [Math]::Max($workArea.Left + 4.0, $window.Left - $effectWindow.Width - $gap)
        }
    }
    $effectWindow.Top = $window.Top + $window.Height - $effectWindow.Height + 2

    $cleanupTimer = New-Object System.Windows.Threading.DispatcherTimer
    $cleanupTimer.Interval = [TimeSpan]::FromSeconds([Math]::Max(5, [int]$script:settings['poopLifetimeSeconds']))
    $cleanupTimer.Add_Tick({
        $this.Stop()
        try { $effectWindow.Close() } catch { }
    })
    $poopText.Add_MouseLeftButtonDown({
        $cleanupTimer.Stop()
        try { $effectWindow.Close() } catch { }
        $_.Handled = $true
    })
    $effectWindow.Add_Closed({
        try { if ($null -ne $cleanupTimer) { $cleanupTimer.Stop() } } catch { Write-DebugLog ('effect-cleanup-timer-error=' + $_.Exception.Message) }
        try {
            $script:poopEffects = @($script:poopEffects | Where-Object { $null -ne $_ -and $_.Window -ne $effectWindow })
        } catch { Write-DebugLog ('effect-cleanup-list-error=' + $_.Exception.Message) }
    })
    $script:poopEffects += [pscustomobject]@{ Window = $effectWindow; Timer = $cleanupTimer }
    # 先把豆皮向反方向挪开，再显示便便，避免拥有窗口跟随移动而再次重叠。
    $newLeft = $window.Left + ($avoidDirection * $avoidDistance)
    $newLeft = [Math]::Max($workArea.Left + 4.0, [Math]::Min($workArea.Right - $window.Width - 4.0, $newLeft))
    $window.Left = $newLeft
    $effectWindow.Show()
    Write-DebugLog "poop-position=$([Math]::Round($effectWindow.Left)) pet-away=$([Math]::Round($avoidDistance))"
    $cleanupTimer.Start()
}

function End-Action {
    $script:toyBall.Visibility = [System.Windows.Visibility]::Hidden
    Reset-PetTransform
    $script:currentAction = 'idle'
    $script:actionAnimation = 'idle'
    $script:actionStartedAt = [DateTime]::UtcNow
    $script:actionDurationMs = 0.0
    $script:actionPoopDropped = $false
    $script:nextIdlePoseAt = if ($script:idlePoseMode -eq 'auto') { [DateTime]::UtcNow.AddMinutes((Get-IdleRotationMinutes)) } else { [DateTime]::MaxValue }
    Set-StableIdleFrame
}

function Start-Action([string]$name, [bool]$force = $false) {
    if ($script:paused -or $script:dragging) { return $false }
    if ($script:currentAction -ne 'idle') {
        if (-not $force) { return $false }
        End-Action
    }

    # 自动待机切换被打断时，先落在一个稳定姿态，动作结束后再继续计时。
    Resolve-IdlePoseTransition

    $script:currentAction = $name
    $script:actionStartedAt = [DateTime]::UtcNow
    $script:actionPoopDropped = $false
    Reset-PetTransform
    $script:toyBall.Visibility = [System.Windows.Visibility]::Hidden

    switch ($name) {
        'scratch' {
            $script:actionAnimation = 'scratchLift'
            $script:scratchCyclesRemaining = Get-Random -Minimum 2 -Maximum 6
            $script:scratchLiftMs = Get-AnimationCycleMs 'scratchLift'
            $script:scratchStrokeMs = [double]$script:scratchCyclesRemaining * (Get-AnimationCycleMs 'scratchStroke')
            $script:scratchLowerMs = Get-AnimationCycleMs 'scratchLower'
            $script:actionDurationMs = $script:scratchLiftMs + $script:scratchStrokeMs + $script:scratchLowerMs
            Reset-NextDue 'scratch'
            Write-DebugLog "scratch-plan=cycles:$($script:scratchCyclesRemaining) phases=hind-leg-lift-stroke-lower-recover lick=disabled"
        }
        'lie' {
            $script:actionAnimation = 'lie'
            $script:actionDurationMs = Get-AnimationCycleMs 'lie'
        }
        'drag-right' {
            $script:actionAnimation = 'right'
            $script:actionDurationMs = Get-AnimationCycleMs 'right'
            $script:lastDirection = 'right'
        }
        'drag-left' {
            $script:actionAnimation = 'left'
            $script:actionDurationMs = Get-AnimationCycleMs 'left'
            $script:lastDirection = 'left'
        }
        'toy' {
            $script:actionAnimation = 'toy'
            $script:actionDurationMs = 5200.0
            $script:toyBall.Visibility = [System.Windows.Visibility]::Visible
            Reset-NextDue 'toy'
        }
        'patrol' {
            $workArea = [System.Windows.SystemParameters]::WorkArea
            $minimum = $workArea.Left + 4
            $maximum = $workArea.Right - $window.Width - 4
            $distance = [double](Get-Random -Minimum 70 -Maximum 111)
            $available = [Math]::Max(40.0, $maximum - $minimum)
            $distance = [Math]::Min($distance, [Math]::Max(20.0, $available / 2.0))
            $safeMinimum = $minimum + $distance
            $safeMaximum = $maximum - $distance
            if ($safeMinimum -gt $safeMaximum) {
                $safeMinimum = $minimum
                $safeMaximum = $maximum
            }
            $start = [Math]::Max($safeMinimum, [Math]::Min($safeMaximum, $window.Left))
            $direction = $script:patrolNextDirection
            $script:patrolNextDirection = -1.0 * $script:patrolNextDirection
            $script:patrolStartLeft = $start
            $script:patrolReturnLeft = $start
            $script:patrolTargetLeft = [Math]::Max($minimum, [Math]::Min($maximum, $start + ($distance * $direction)))
            $window.Left = $start
            $script:patrolOutDirection = if ($script:patrolTargetLeft -ge $script:patrolStartLeft) { 1.0 } else { -1.0 }
            $script:lastDirection = if ($script:patrolOutDirection -gt 0) { 'right' } else { 'left' }
            $script:actionAnimation = if ($script:patrolOutDirection -gt 0) { 'right' } else { 'left' }
            $script:patrolRunCount++
            $script:actionDurationMs = 5600.0
            Write-DebugLog "patrol-out=$($script:lastDirection) return=true run=$($script:patrolRunCount)"
            Reset-NextDue 'patrol'
        }
        'poop' {
            $script:actionAnimation = 'poop'
            $script:actionDurationMs = Get-AnimationCycleMs 'poop'
            Reset-NextDue 'poop'
        }
        default {
            End-Action
            return $false
        }
    }
    Write-DebugLog "action-start=$name"
    Show-AnimationFrame $script:actionAnimation 0
    return $true
}

function Update-Action([DateTime]$now) {
    if ($script:currentAction -eq 'idle') { Update-IdlePose $now; return }
    $elapsed = ($now - $script:actionStartedAt).TotalMilliseconds

    switch ($script:currentAction) {
        'patrol' {
            $half = $script:actionDurationMs / 2.0
            if ($elapsed -le $half) {
                $progress = [Math]::Min(1.0, $elapsed / $half)
                $eased = 0.5 - (0.5 * [Math]::Cos([Math]::PI * $progress))
                $window.Left = $script:patrolStartLeft + (($script:patrolTargetLeft - $script:patrolStartLeft) * $eased)
                $script:actionAnimation = if ($script:patrolOutDirection -gt 0) { 'right' } else { 'left' }
                Show-AnimationFrame $script:actionAnimation $elapsed
            } else {
                $returnElapsed = $elapsed - $half
                $progress = [Math]::Min(1.0, $returnElapsed / $half)
                $eased = 0.5 - (0.5 * [Math]::Cos([Math]::PI * $progress))
                $window.Left = $script:patrolTargetLeft + (($script:patrolReturnLeft - $script:patrolTargetLeft) * $eased)
                $script:actionAnimation = if ($script:patrolOutDirection -gt 0) { 'left' } else { 'right' }
                Show-AnimationFrame $script:actionAnimation $returnElapsed
            }
        }
        'toy' {
            $progress = [Math]::Min(1.0, $elapsed / $script:actionDurationMs)
            $ballSize = $script:toyBall.Width
            $travel = [Math]::Max(12.0, $window.Width - $ballSize - 12.0)
            $x = 6.0 + ($travel * (0.5 - (0.5 * [Math]::Cos(4.0 * [Math]::PI * $progress))))
            $ground = [Math]::Max(4.0, $window.Height - $ballSize - 7.0)
            $bounce = [Math]::Abs([Math]::Sin(6.0 * [Math]::PI * $progress))
            $y = $ground - ([Math]::Min(30.0, $window.Height * 0.22) * $bounce)
            [System.Windows.Controls.Canvas]::SetLeft($script:toyBall, $x)
            [System.Windows.Controls.Canvas]::SetTop($script:toyBall, $y)
            $script:petRotate.Angle = 2.2 * [Math]::Sin(4.0 * [Math]::PI * $progress)
            $script:petTranslate.X = 2.5 * [Math]::Sin(4.0 * [Math]::PI * $progress)
            Show-AnimationFrame 'toy' $elapsed
        }
        'poop' {
            $progress = [Math]::Min(1.0, $elapsed / $script:actionDurationMs)
            $phase = [Math]::Sin([Math]::PI * $progress)
            $script:petScale.ScaleX = 1.0 + (0.045 * $phase)
            $script:petScale.ScaleY = 1.0 - (0.065 * $phase)
            $script:petTranslate.Y = 5.0 * $phase
            Show-AnimationFrame 'poop' $elapsed
            if (-not $script:actionPoopDropped -and $elapsed -ge 1550.0) {
                $script:actionPoopDropped = $true
                New-PoopWindow
            }
        }
        'scratch' {
            $phaseElapsed = $elapsed
            if ($phaseElapsed -lt $script:scratchLiftMs) {
                Show-AnimationFrame 'scratchLift' $phaseElapsed
            } else {
                $phaseElapsed = $phaseElapsed - $script:scratchLiftMs
                if ($phaseElapsed -lt $script:scratchStrokeMs) {
                    Show-AnimationFrame 'scratchStroke' $phaseElapsed
                } else {
                    $phaseElapsed = $phaseElapsed - $script:scratchStrokeMs
                    Show-AnimationFrame 'scratchLower' $phaseElapsed
                }
            }
        }
        default {
            Show-AnimationFrame $script:actionAnimation $elapsed
        }
    }

    if ($elapsed -ge $script:actionDurationMs) {
        if ($script:currentAction -eq 'patrol') { $window.Left = $script:patrolReturnLeft }
        Write-DebugLog "action-end=$($script:currentAction)"
        End-Action
    }
}

function Invoke-Scheduler([DateTime]$now) {
    if ($script:smokeMode -or $script:paused -or $script:dragging -or $script:currentAction -ne 'idle') { return }
    if ($now -ge $script:nextPoopAt) { [void](Start-Action 'poop'); return }
    if ($now -ge $script:nextToyAt) { [void](Start-Action 'toy'); return }
    if ($now -ge $script:nextPatrolAt) { [void](Start-Action 'patrol'); return }
    if ($now -ge $script:nextScratchAt) { [void](Start-Action 'scratch'); return }
}

$window = New-Object System.Windows.Window
$window.Title = '豆皮 2.8.2'
$window.WindowStyle = [System.Windows.WindowStyle]::None
$window.ResizeMode = [System.Windows.ResizeMode]::NoResize
$window.AllowsTransparency = $true
$window.Background = [System.Windows.Media.Brushes]::Transparent
$window.ShowInTaskbar = $false
$window.Topmost = $true
$window.ShowActivated = $false
$window.SnapsToDevicePixels = $true
$window.UseLayoutRounding = $true

$script:canvas = New-Object System.Windows.Controls.Canvas
$script:canvas.Background = [System.Windows.Media.Brushes]::Transparent

$script:petImage = New-Object System.Windows.Controls.Image
$script:petImage.Stretch = [System.Windows.Media.Stretch]::Fill
$script:petImage.SnapsToDevicePixels = $true
[System.Windows.Media.RenderOptions]::SetBitmapScalingMode($script:petImage, [System.Windows.Media.BitmapScalingMode]::HighQuality)

$script:petScale = New-Object System.Windows.Media.ScaleTransform(1.0, 1.0)
$script:petRotate = New-Object System.Windows.Media.RotateTransform(0.0)
$script:petTranslate = New-Object System.Windows.Media.TranslateTransform(0.0, 0.0)
$petTransform = New-Object System.Windows.Media.TransformGroup
$petTransform.Children.Add($script:petScale) | Out-Null
$petTransform.Children.Add($script:petRotate) | Out-Null
$petTransform.Children.Add($script:petTranslate) | Out-Null
$script:petImage.RenderTransform = $petTransform
$script:petImage.RenderTransformOrigin = New-Object System.Windows.Point(0.5, 1.0)

$script:toyBall = New-Object System.Windows.Shapes.Ellipse
$script:toyBall.IsHitTestVisible = $false
$script:toyBall.Visibility = [System.Windows.Visibility]::Hidden
$script:toyBall.Stroke = [System.Windows.Media.Brushes]::White
$script:toyBall.StrokeThickness = 1.5
$ballBrush = New-Object System.Windows.Media.RadialGradientBrush
$ballBrush.GradientStops.Add((New-Object System.Windows.Media.GradientStop([System.Windows.Media.Color]::FromRgb(255,232,90),0.0))) | Out-Null
$ballBrush.GradientStops.Add((New-Object System.Windows.Media.GradientStop([System.Windows.Media.Color]::FromRgb(255,120,45),0.58))) | Out-Null
$ballBrush.GradientStops.Add((New-Object System.Windows.Media.GradientStop([System.Windows.Media.Color]::FromRgb(62,130,220),1.0))) | Out-Null
$script:toyBall.Fill = $ballBrush

$script:canvas.Children.Add($script:petImage) | Out-Null
$script:canvas.Children.Add($script:toyBall) | Out-Null
$window.Content = $script:canvas

$initialScale = [double]$script:settings['displayScale']
if ($initialScale -le 0) { $initialScale = Get-AutoScale }
$window.Width = [Math]::Round($script:cellWidth * $initialScale)
$window.Height = [Math]::Round($script:cellHeight * $initialScale)
$workArea = [System.Windows.SystemParameters]::WorkArea
$window.Left = $workArea.Right - $window.Width - 150
$window.Top = $workArea.Bottom - $window.Height - 16
Set-DisplayScale $initialScale $false

function Add-MenuItem([System.Windows.Controls.ItemsControl]$parent, [string]$label, [scriptblock]$action) {
    $item = New-Object System.Windows.Controls.MenuItem
    $item.Header = $label
    $item.FontSize = 13
    $item.Padding = New-Object System.Windows.Thickness(10,6,10,6)
    $item.Add_Click($action)
    $parent.Items.Add($item) | Out-Null
    return $item
}

function Add-IntervalMenu([System.Windows.Controls.ContextMenu]$menu, [string]$title, [string]$kind, [object[]]$options) {
    $submenu = New-Object System.Windows.Controls.MenuItem
    $submenu.Header = $title
    $menu.Items.Add($submenu) | Out-Null
    foreach ($option in $options) {
        $item = New-Object System.Windows.Controls.MenuItem
        $item.Header = $option.Label
        $item.Tag = [pscustomobject]@{ Kind = $kind; Seconds = [int]$option.Seconds }
        $item.Add_Click({ Set-IntervalSetting ([string]$this.Tag.Kind) ([int]$this.Tag.Seconds) })
        $submenu.Items.Add($item) | Out-Null
    }
}

$menu = New-Object System.Windows.Controls.ContextMenu
$menu.Background = [System.Windows.Media.Brushes]::White
$menu.Foreground = [System.Windows.Media.Brushes]::Black

$actionMenu = New-Object System.Windows.Controls.MenuItem
$actionMenu.Header = '立即互动'
$menu.Items.Add($actionMenu) | Out-Null
Add-MenuItem $actionMenu '玩玩具' { [void](Start-Action 'toy' $true) } | Out-Null
Add-MenuItem $actionMenu '跑一跑' { [void](Start-Action 'patrol' $true) } | Out-Null
Add-MenuItem $actionMenu '挠挠头' { [void](Start-Action 'scratch' $true) } | Out-Null
Add-MenuItem $actionMenu '趴下休息' { [void](Start-Action 'lie' $true) } | Out-Null
Add-MenuItem $actionMenu '拉一下' { [void](Start-Action 'poop' $true) } | Out-Null

$idlePoseMenu = New-Object System.Windows.Controls.MenuItem
$idlePoseMenu.Header = '待机姿态'
$menu.Items.Add($idlePoseMenu) | Out-Null
Add-MenuItem $idlePoseMenu '恢复自动轮换' { Set-IdlePoseMode 'auto' } | Out-Null
Add-MenuItem $idlePoseMenu '立即坐下并保持' { Set-IdlePoseMode 'sit' } | Out-Null
Add-MenuItem $idlePoseMenu '立即趴卧并保持' { Set-IdlePoseMode 'lie' } | Out-Null
Add-MenuItem $idlePoseMenu '立即团起来并保持' { Set-IdlePoseMode 'curled' } | Out-Null
$idleRotationMenu = New-Object System.Windows.Controls.MenuItem
$idleRotationMenu.Header = '自动轮换间隔'
$idlePoseMenu.Items.Add($idleRotationMenu) | Out-Null
Add-MenuItem $idleRotationMenu '每 5 分钟' { Set-IdleRotationMinutes 5 } | Out-Null
Add-MenuItem $idleRotationMenu '每 10 分钟' { Set-IdleRotationMinutes 10 } | Out-Null
Add-MenuItem $idleRotationMenu '每 20 分钟' { Set-IdleRotationMinutes 20 } | Out-Null

$menu.Items.Add((New-Object System.Windows.Controls.Separator)) | Out-Null
Add-IntervalMenu $menu '自动玩玩具' 'toy' @(
    @{Label='关闭';Seconds=0}, @{Label='每 60 秒';Seconds=60}, @{Label='每 120 秒';Seconds=120}, @{Label='每 240 秒';Seconds=240}
)
Add-IntervalMenu $menu '自动小跑' 'patrol' @(
    @{Label='关闭';Seconds=0}, @{Label='每 60 秒';Seconds=60}, @{Label='每 120 秒';Seconds=120}, @{Label='每 240 秒';Seconds=240}
)
Add-IntervalMenu $menu '自动挠头' 'scratch' @(
    @{Label='关闭';Seconds=0}, @{Label='每 120 秒';Seconds=120}, @{Label='每 240 秒';Seconds=240}, @{Label='每 300 秒';Seconds=300}
)
Add-IntervalMenu $menu '排便间隔' 'poop' @(
    @{Label='关闭';Seconds=0}, @{Label='每 1 小时';Seconds=3600}, @{Label='每 1.5 小时';Seconds=5400}, @{Label='每 2 小时';Seconds=7200}
)

$menu.Items.Add((New-Object System.Windows.Controls.Separator)) | Out-Null
$sizeMenu = New-Object System.Windows.Controls.MenuItem
$sizeMenu.Header = '显示大小'
$menu.Items.Add($sizeMenu) | Out-Null
Add-MenuItem $sizeMenu '自动' { Set-DisplayScale (Get-AutoScale) } | Out-Null
Add-MenuItem $sizeMenu '小巧（45%）' { Set-DisplayScale 0.45 } | Out-Null
Add-MenuItem $sizeMenu '推荐（52%）' { Set-DisplayScale 0.52 } | Out-Null
Add-MenuItem $sizeMenu '稍大（62%）' { Set-DisplayScale 0.62 } | Out-Null
Add-MenuItem $sizeMenu '较大（75%）' { Set-DisplayScale 0.75 } | Out-Null

$menu.Items.Add((New-Object System.Windows.Controls.Separator)) | Out-Null
$pauseItem = Add-MenuItem $menu '暂停自动动作' {
    $script:paused = -not $script:paused
    if ($script:paused) {
        End-Action
        $pauseItem.Header = '继续自动动作'
    } else {
        $pauseItem.Header = '暂停自动动作'
    }
}
Add-MenuItem $menu '清理便便' { Close-AllPoop } | Out-Null
Add-MenuItem $menu '回到右下角' {
    $area = [System.Windows.SystemParameters]::WorkArea
    $window.Left = $area.Right - $window.Width - 150
    $window.Top = $area.Bottom - $window.Height - 16
} | Out-Null
Add-MenuItem $menu '关于豆皮 2.8.2' {
    [System.Windows.MessageBox]::Show(
        "豆皮独立桌面宠物 2.8.2`n`n会自己玩玩具、小范围奔跑，并可在坐姿、趴卧和团睡之间自动轮换。`n所有自动动作都可在右键菜单关闭。",
        '关于豆皮 2.8.2',
        [System.Windows.MessageBoxButton]::OK,
        [System.Windows.MessageBoxImage]::Information
    ) | Out-Null
} | Out-Null
Add-MenuItem $menu '退出豆皮' { $window.Close() } | Out-Null
$script:petImage.ContextMenu = $menu

$script:petImage.Add_PreviewMouseRightButtonDown({
    $point = $_.GetPosition($script:petImage)
    if (-not (Test-PetPixel $point)) { $_.Handled = $true }
})

$script:petImage.Add_MouseLeftButtonDown({
    try {
        $point = $_.GetPosition($script:petImage)
        if (-not (Test-PetPixel $point)) { return }
        End-Action
        $script:dragging = $true
        $startLeft = $window.Left
        $startTop = $window.Top
        try { $window.DragMove() } catch { Write-DebugLog ('drag-error=' + $_.Exception.Message) }
        $script:dragging = $false
        $dx = $window.Left - $startLeft
        $dy = $window.Top - $startTop
        $moved = (($dx * $dx) + ($dy * $dy)) -ge 9.0
        if ($moved) {
            if ($dx -lt -3) { [void](Start-Action 'drag-left') }
            elseif ($dx -gt 3) { [void](Start-Action 'drag-right') }
            else { End-Action }
        } else {
            $choice = Get-Random -InputObject @('toy','scratch')
            Write-DebugLog "click-choice=$choice"
            [void](Start-Action $choice $true)
        }
        $_.Handled = $true
    } catch {
        $script:dragging = $false
        End-Action
        Write-DebugLog ('mouse-error=' + $_.Exception.Message)
    }
})

Reset-NextDue 'scratch'
Reset-NextDue 'toy'
Reset-NextDue 'patrol'
Reset-NextDue 'poop'
Set-StableIdleFrame

$engineTimer = New-Object System.Windows.Threading.DispatcherTimer
$engineTimer.Interval = [TimeSpan]::FromMilliseconds(33)
$engineTimer.Add_Tick({
    try {
        $now = [DateTime]::UtcNow
        if (-not $script:paused) { Update-Action $now }
        Invoke-Scheduler $now
    } catch {
        # 单个动作/帧异常不能关闭主窗口；记录后回到安全待机。
        if (([DateTime]::UtcNow - $script:lastEngineErrorAt).TotalSeconds -ge 5) {
            $script:lastEngineErrorAt = [DateTime]::UtcNow
            Write-DebugLog ('engine-error=' + $_.Exception.ToString())
        }
        try { Reset-PetTransform } catch { }
        try { End-Action } catch { $script:currentAction = 'idle' }
    }
})

$window.Add_Closing({ Write-DebugLog 'window-closing' })
$window.Add_Closed({
    Write-DebugLog 'window-closed'
    try { if ($null -ne $engineTimer) { $engineTimer.Stop() } } catch { Write-DebugLog ('cleanup-engine-error=' + $_.Exception.Message) }
    try { if ($null -ne $script:smokeTimer) { $script:smokeTimer.Stop() } } catch { Write-DebugLog ('cleanup-smoke-error=' + $_.Exception.Message) }
    try { Close-AllPoop } catch { Write-DebugLog ('cleanup-effect-error=' + $_.Exception.Message) }
    Write-DebugLog 'window-cleanup-effects-done'
    if ($null -ne $script:instanceMutex) {
        try { $script:instanceMutex.ReleaseMutex() } catch { }
        try { $script:instanceMutex.Dispose() } catch { }
        $script:instanceMutex = $null
    }
    try {
        if ((Test-Path -LiteralPath $script:pidPath) -and ((Get-Content -LiteralPath $script:pidPath -Raw).Trim() -eq [string]$PID)) {
            Remove-Item -LiteralPath $script:pidPath -Force -ErrorAction SilentlyContinue
        }
    } catch { }
})

$app = New-Object System.Windows.Application
$app.MainWindow = $window
$app.ShutdownMode = [System.Windows.ShutdownMode]::OnMainWindowClose
$app.Add_DispatcherUnhandledException({
    Write-DebugLog ('dispatcher-error=' + $_.Exception.ToString())
    try { Reset-PetTransform } catch { }
    try { End-Action } catch { $script:currentAction = 'idle' }
    $_.Handled = $true
})
$engineTimer.Start()
Write-DebugLog 'app-start'
if ($SmokeTestSeconds -gt 0) {
    $script:smokeStartedAt = [DateTime]::UtcNow
    $script:smokeIndex = 0
    $script:smokeSchedule = @(
        [pscustomobject]@{ At = 0.6; Action = 'toy' },
        [pscustomobject]@{ At = 6.0; Action = 'patrol' },
        [pscustomobject]@{ At = 12.4; Action = 'poop' }
    )
    $script:smokeTimer = New-Object System.Windows.Threading.DispatcherTimer
    $script:smokeTimer.Interval = [TimeSpan]::FromMilliseconds(100)
    $script:smokeTimer.Add_Tick({
        $elapsedSeconds = ([DateTime]::UtcNow - $script:smokeStartedAt).TotalSeconds
        if ($SmokeDemo -and $script:smokeIndex -lt $script:smokeSchedule.Count) {
            $step = $script:smokeSchedule[$script:smokeIndex]
            if ($elapsedSeconds -ge [double]$step.At) {
                [void](Start-Action ([string]$step.Action) $true)
                $script:smokeIndex++
            }
        }
        if ($elapsedSeconds -ge $SmokeTestSeconds) {
            Write-DebugLog 'smoke-test-complete'
            $script:smokeTimer.Stop()
            try { Close-AllPoop } catch { }
            try { $window.Close() } catch { }
            try { $app.Shutdown(0) } catch { Write-DebugLog ('smoke-shutdown-error=' + $_.Exception.Message) }
        }
    })
    $script:smokeTimer.Start()
}
try {
    $app.Run($window) | Out-Null
    Write-DebugLog 'app-run-ended'
} catch {
    Write-DebugLog ('app-error=' + ($_ | Out-String).Trim())
    throw
} finally {
    try { Close-AllPoop } catch { }
    if ($null -ne $script:instanceMutex) {
        try { $script:instanceMutex.ReleaseMutex() } catch { }
        try { $script:instanceMutex.Dispose() } catch { }
        $script:instanceMutex = $null
    }
    try {
        if ((Test-Path -LiteralPath $script:pidPath) -and ((Get-Content -LiteralPath $script:pidPath -Raw).Trim() -eq [string]$PID)) {
            Remove-Item -LiteralPath $script:pidPath -Force -ErrorAction SilentlyContinue
        }
    } catch { }
}
exit 0
