@echo off
setlocal
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0DoupiPet2.ps1" -DebugLogPath "%~dp0DoupiPet2-debug.log"
endlocal
