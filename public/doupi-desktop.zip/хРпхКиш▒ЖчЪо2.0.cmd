@echo off
call "%~dp0launch-doupi-2.cmd"
